#include <Arduino.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <LiquidCrystal_I2C.h>

#include <ArduinoJson.h>

// ================= WIFI =================

#define WIFI_SSID "Wokwi-GUEST"
#define WIFI_PASSWORD ""


// ================= SUPABASE =================

#define SUPABASE_URL "https://kewebmnmqrylxkggrkua.supabase.co/rest/v1/streetlight_data"

#define SUPABASE_API_KEY "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imtld2VibW5tcXJ5bHhrZ2dya3VhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODIxMDAxNDEsImV4cCI6MjA5NzY3NjE0MX0.JtjqxplRIpN9pF_5KJhf9q5OTKyagc2APe90wwkuvrk"


// ================= LCD =================

LiquidCrystal_I2C lcd(0x27,16,2);


// ================= PINS =================

#define LDR_PIN 34

#define RED_PIN 17
#define GREEN_PIN 16
#define BLUE_PIN 4

#define STREET_LED 15


// ================= VARIABLES =================

unsigned long lastSend = 0;

const unsigned long interval = 5000;

bool blinkState = false;


// ================= FUNCTIONS =================

void connectWiFi();

void setRGB(bool r, bool g, bool b)
{
  digitalWrite(RED_PIN, r);
  digitalWrite(GREEN_PIN, g);
  digitalWrite(BLUE_PIN, b);
}

void sendToSupabase(
  int intensity,
  String streetStatus,
  String rgbStatus
);



// ================= SETUP =================

void setup()
{

  Serial.begin(115200);


  pinMode(RED_PIN,OUTPUT);

  pinMode(GREEN_PIN,OUTPUT);

  pinMode(BLUE_PIN,OUTPUT);

  pinMode(STREET_LED,OUTPUT);


  lcd.init();

  lcd.backlight();


  lcd.setCursor(0,0);

  lcd.print("SMART STREET");

  lcd.setCursor(0,1);

  lcd.print("LIGHT SYSTEM");


  delay(2000);

  lcd.clear();


  connectWiFi();

}


// ================= LOOP =================

void loop()
{

  int ldrValue = analogRead(LDR_PIN);


  int intensity = map(
      ldrValue,
      4095,
      0,
      0,
      100
  );

  intensity = constrain(
      intensity,
      0,
      100
  );


  String streetStatus;

  String rgbStatus;

  // Bright
  if (intensity > 70)
  {
      setRGB(HIGH, LOW, HIGH); // Green
      digitalWrite(STREET_LED, LOW);

      streetStatus = "OFF";
      rgbStatus = "GREEN";
  }

  // Moderate
  else if (intensity >= 30)
  {
      setRGB(HIGH, HIGH, LOW); // Blue
      digitalWrite(STREET_LED, LOW);

      streetStatus = "OFF";
      rgbStatus = "BLUE";
  }

  // Very Dark
  else if (intensity < 15)
  {
      static unsigned long lastBlink = 0;

      digitalWrite(GREEN_PIN, HIGH);
      digitalWrite(BLUE_PIN, HIGH);

      if (millis() - lastBlink >= 500)
      {
          blinkState = !blinkState;

          // Common Anode: LOW = ON
          digitalWrite(RED_PIN, blinkState ? LOW : HIGH);

          lastBlink = millis();
      }

      digitalWrite(STREET_LED, HIGH);

      streetStatus = "ON";
      rgbStatus = "RED BLINK";
  }

  // Dark
  else
  {
      setRGB(LOW, HIGH, HIGH); // Red
      digitalWrite(STREET_LED, HIGH);

      streetStatus = "ON";
      rgbStatus = "RED";
  }

  // LCD

  lcd.clear();


  lcd.setCursor(0,0);

  lcd.print("Light:");

  lcd.print(intensity);

  lcd.print("%");


  lcd.setCursor(0,1);

  lcd.print("Street:");

  lcd.print(streetStatus);




  // SEND EVERY 5 SEC

  if(millis()-lastSend >= interval)
  {

    lastSend = millis();


    sendToSupabase(
      intensity,
      streetStatus,
      rgbStatus
    );

  }


  delay(500);

}



// ================= WIFI =================

void connectWiFi()
{

  WiFi.begin(
    WIFI_SSID,
    WIFI_PASSWORD
  );

  lcd.clear();

  lcd.print("Connecting...");


  while(WiFi.status()!=WL_CONNECTED)
  {

    delay(500);

    Serial.print(".");

  }


  Serial.println();

  Serial.println("WiFi Connected");


  lcd.clear();

  lcd.print("WiFi Connected");

  delay(1000);

}

// ================= SUPABASE =================

void sendToSupabase(
  int intensity,
  String streetStatus,
  String rgbStatus
)

{

  if(WiFi.status()==WL_CONNECTED)
  {

    WiFiClientSecure client;

    client.setInsecure();


    HTTPClient http;


    http.begin(
      client,
      SUPABASE_URL
    );


    http.addHeader(
      "Content-Type",
      "application/json"
    );


    http.addHeader(
      "apikey",
      SUPABASE_API_KEY
    );


    http.addHeader(
      "Authorization",
      "Bearer " + String(SUPABASE_API_KEY)
    );

    http.addHeader(
      "Prefer",
      "return=representation"
    );




    // MATCH TABLE COLUMN NAMES

    String json =

    "{"
    "\"intensity\":" + String(intensity) +
    ",\"streetStatus\":\"" + streetStatus +
    "\",\"rgbStatus\":\"" + rgbStatus +
    "\""
    "}";



    Serial.println("Sending:");

    Serial.println(json);



    int responseCode = http.POST(json);


    Serial.print("HTTP Response: ");

    Serial.println(responseCode);


    String response = http.getString();

    Serial.println("Supabase:");

    Serial.println(response);


    http.end();

  }

}
